import { StyleSheet, Dimensions } from "react-native"

export const helpers = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: 'center'
  },
  pr_1: {
    paddingRight: 10
  }
})
